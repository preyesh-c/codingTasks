import unittest
from task import Task
from data_access import load_tasks, save_tasks, add_task

# test the ability to run multiple aspects of the task manager program

class TestTaskManager(unittest.TestCase):
    def setUp(self):
        self.task = Task(1, "Task 1", "Description of Task 1", False)
        self.tasks_file = 'tasks.txt'
    
    def tearDown(self):
        import os
        if os.path.exists(self.tasks_file):
            os.remove(self.tasks_file)

    def test_task_creation(self):
        self.assertEqual(self.task.task_id, 1)
        self.assertEqual(self.task.title, "Task 1")
        self.assertEqual(self.task.description, "Description of Task 1")
        self.assertFalse(self.task.completed)

    def test_add_and_load_task(self):
        add_task(self.task)
        tasks = load_tasks()
        self.assertEqual(len(tasks), 2)
        self.assertEqual(tasks[0].task_id, self.task.task_id)
        self.assertEqual(tasks[0].title, self.task.title)
        self.assertEqual(tasks[0].description, self.task.description)
        self.assertEqual(tasks[0].completed, self.task.completed)

    def test_mark_completed(self):
        self.task.mark_completed()
        self.assertTrue(self.task.completed)
        save_tasks([self.task])
        tasks = load_tasks()
        self.assertTrue(tasks[0].completed)

    def test_view_of_tasks(self):
        self.assertEqual(self.task.description, "Description of Task 5")

    def test_view_of_task_in_progress(self):
        self.assertEqual(self.task_id, "ID 567")
        
    if __name__ == "__main__":
        unittest.main()