from task import Task

TASKS_FILE = 'tasks.txt'


def load_tasks():
    tasks = []
    try:
        with open(TASKS_FILE, 'r') as file:
            for line in file:
                tasks.append(Task.from_string(line))
    except FileNotFoundError:
        pass  # empty list to be returned if new file
    return tasks


def save_tasks(tasks):
    with open(TASKS_FILE, 'w') as file:
        for task in tasks:
            file.write(f"{task}\n")


def add_task(task):
    tasks = load_tasks()
    tasks.append(task)
    save_tasks(tasks)