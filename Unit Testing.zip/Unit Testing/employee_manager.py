# This following programme is an employee manager for staff at a company
# The class below manages new joiners and leavers

class EmployeeManager:

    def __init__(self) -> None:
        self.employees = []

    def add_employee(self, employee):
        if self.get_employee(employee.id):
            return
        self.employees.append(employee)

    def get_employee(self, id):
        for employee in self.employees:
            if employee.id == id:
                return employee
        
    def remove_employee_leaver(self, id):
        for i in range(len(self.employees)):
            if self.employees[i].id == id:
                del self.employees[i]

# This class holds information about an employee, particularly their appraisal scores during performance reviews
class Employee:

    def __init__(self, id, name, surname, address=""):
        self.id = id
        self.name = name
        self.surname = surname
        self.address = address
        self.scores = {}

    def add_score(self, department, score):
        if isinstance(department, str) and isinstance(score, (int, float)):
            self.scores[department] = score

    def get_score_average(self):
        score_total = 0
        if not self.scores:
            return
        for score in self.scores.values():
            score_total += score
        return score_total/len(self.scores)

    

