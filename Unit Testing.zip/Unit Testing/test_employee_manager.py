# We want to test adding details to employee records, such as adding their appraisal score
# We also want to test adding new employees to our manager, ensuring that they are assigned a unique id

import unittest
from employee_manager import Employee, EmployeeManager

class TestEmployee(unittest.TestCase):

    def setUp(self) -> None:
        # Arrange
        self.employee = Employee(0, "James", "Smith")

    def test_adding_a_score_to_employee(self):
        # Act
        self.employee.add_score("Marketing", 50)
        # Assert
        self.assertEqual(self.employee.scores, {"Marketing":50})
    
    def test_adding_score_with_incorrect_input(self):
        self.employee.add_score(55, 60)
        self.assertEqual(self.employee.scores, {})

# This class tests the employee manager for adding new joiners
class TestEmployeeManager(unittest.TestCase):

    def setUp(self) -> None:
        self.employee_manager = EmployeeManager()

    def test_adding_employee_to_manager(self):
        new_employee = Employee(1, "James", "Parker")
        self.employee_manager.add_employee(new_employee)
        self.assertListEqual(self.employee_manager.employees,[new_employee])

    def test_adding_employee_with_same_id(self):
        employee1 = Employee(1, "Eric", "Cantona")
        employee2 = Employee(1, "Thierry", "Henry")
        self.employee_manager.add_employee(employee1)
        self.employee_manager.add_employee(employee2)
        self.assertListEqual(self.employee_manager.employees, [employee1])

if __name__ == "__main__":
    unittest.main() 